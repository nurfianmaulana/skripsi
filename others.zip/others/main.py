penyakit = [
    {'id': 1, 'code': 'P1', 'name': 'Typus Ayam'},
    {'id': 2, 'code': 'P2', 'name': 'TBC'},
    {'id': 3, 'code': 'P3', 'name': 'Kolera'},
    {'id': 4, 'code': 'P4', 'name': 'CRD'},
    {'id': 5, 'code': 'P5', 'name': 'Pilek'},
    {'id': 6, 'code': 'P6', 'name': 'Berak Lumpur'},
    {'id': 7, 'code': 'P7', 'name': 'Berak Darah'},
    {'id': 8, 'code': 'P8', 'name': 'Hostomatosis'},
    {'id': 9, 'code': 'P9', 'name': 'Radang Paru - Paru'},
    {'id': 10, 'code': 'P10', 'name': 'Influenza Ayam'},
    {'id': 11, 'code': 'P11', 'name': 'Sesak Nafas'},
    {'id': 12, 'code': 'P12', 'name': 'Gumoro'},
]
# penyakit = [
#     {'id': 1, 'code': 1, 'name': 'Typus Ayam'},
#     {'id': 2, 'code': 2, 'name': 'TBC'},
#     {'id': 3, 'code': 3, 'name': 'Kolera'},
#     {'id': 4, 'code': 4, 'name': 'CRD'},
#     {'id': 5, 'code': 5, 'name': 'Pilek'},
#     {'id': 6, 'code': 6, 'name': 'Berak Lumpur'},
#     {'id': 7, 'code': 7, 'name': 'Berak Darah'},
#     {'id': 8, 'code': 8, 'name': 'Hostomatosis'},
#     {'id': 9, 'code': 9, 'name': 'Radang Paru - Paru'},
#     {'id': 10, 'code': 10, 'name': 'Influenza Ayam'},
#     {'id': 11, 'code': 11, 'name': 'Sesak Nafas'},
#     {'id': 12, 'code': 12, 'name': 'Gumoro'},
# ]

gejala = [
    {'id': 1, 'code': 'G1', 'name': 'ayam mengeluarkan kotor'},
    {'id': 2, 'code': 'G2', 'name': 'jengger ayam terlihat pucat'},
    {'id': 3, 'code': 'G3', 'name': 'nafsu makan ayam menurun'},
    {'id': 4, 'code': 'G4', 'name': 'tingkah ayam terlihat lesu'},
    {'id': 5, 'code': 'G5', 'name': 'ayam mudah kehausan'},
    {'id': 6, 'code': 'G6', 'name': 'ayam mendadak mati'},
    {'id': 7, 'code': 'G7', 'name': 'umur ayam kurang dari 1'},
    {'id': 8, 'code': 'G8', 'name': 'dada pada ayam terlihat tipis'},
    {'id': 9, 'code': 'G9', 'name': 'persendian pada ayam bengkak'},
    {'id': 10, 'code': 'G10', 'name': 'ayam sulit bernafas'},
    {'id': 11, 'code': 'G11', 'name': 'ayam batuk'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
    {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
]

basis_pengetahuan = [
    {'id_penyakit': 1, 'id_gejala': 1, 'bobot': 0.7},
    {'id_penyakit': 3, 'id_gejala': 1, 'bobot': 0.7},
    {'id_penyakit': 1, 'id_gejala': 2, 'bobot': 0.6},
    {'id_penyakit': 6, 'id_gejala': 2, 'bobot': 0.6},
    {'id_penyakit': 1, 'id_gejala': 3, 'bobot': 0.8},
    {'id_penyakit': 7, 'id_gejala': 3, 'bobot': 0.8},
    {'id_penyakit': 9, 'id_gejala': 3, 'bobot': 0.8},
    {'id_penyakit': 11, 'id_gejala': 3, 'bobot': 0.8},
    {'id_penyakit': 12, 'id_gejala': 3, 'bobot': 0.8},
    {'id_penyakit': 2, 'id_gejala': 4, 'bobot': 0.5},
    {'id_penyakit': 9, 'id_gejala': 4, 'bobot': 0.5},
    {'id_penyakit': 11, 'id_gejala': 4, 'bobot': 0.5},
    {'id_penyakit': 1, 'id_gejala': 5, 'bobot': 0.6},
    {'id_penyakit': 9, 'id_gejala': 5, 'bobot': 0.6},
    {'id_penyakit': 1, 'id_gejala': 6, 'bobot': 0.9},
    {'id_penyakit': 2, 'id_gejala': 7, 'bobot': 0.7},
    {'id_penyakit': 2, 'id_gejala': 8, 'bobot': 0.6},
    {'id_penyakit': 2, 'id_gejala': 9, 'bobot': 0.7},
    {'id_penyakit': 9, 'id_gejala': 10, 'bobot': 0.8},
    {'id_penyakit': 10, 'id_gejala': 10, 'bobot': 0.8},
    {'id_penyakit': 11, 'id_gejala': 10, 'bobot': 0.8},
    {'id_penyakit': 4, 'id_gejala': 11, 'bobot': 0.6},
    {'id_penyakit': 5, 'id_gejala': 11, 'bobot': 0.6},
    {'id_penyakit': 10, 'id_gejala': 11, 'bobot': 0.6},
    {'id_penyakit': 4, 'id_gejala': 12, 'bobot': 0.5},
    {'id_penyakit': 6, 'id_gejala': 13, 'bobot': 0.7},
]

input_data = [1, 2, 3]

def join_and_group_concat(basis_pengetahuan, penyakit, gejala):
    # Filter basis_pengetahuan by gejala
    filtered_rules = [rule for rule in basis_pengetahuan if rule['id_gejala'] in gejala]

    # Perform the join operation
    joined_data = []
    for rule in filtered_rules:
        problem = next((problem for problem in penyakit if problem['id'] == rule['id_penyakit']), None)
        joined_data.append({
            'id_gejala': rule['id_gejala'],
            'code': problem['code'] if problem else None,
            'bobot': rule['bobot']
        })

    # Group by id_gejala and concatenate codes
    grouped_data = {}
    for item in joined_data:
        if item['id_gejala'] not in grouped_data:
            grouped_data[item['id_gejala']] = {'codes': [], 'bobot': item['bobot']}
        grouped_data[item['id_gejala']]['codes'].append(item['code'])

    # Format the result
    result = [{
        'id_gejala': key,
        'id_penyakit': ','.join(grouped_data[key]['codes']),
        'bobot': grouped_data[key]['bobot']
    } for key in grouped_data]

    return result

def group_concat(arr, separator):
    return ''.join(arr) if not arr else separator.join(arr)

result = join_and_group_concat(basis_pengetahuan, penyakit, input_data)
evidence = []

for i in range(len(result)):
    row = result[i]
    evidence.append([row['id_penyakit'], row['bobot']])

code_penyakit = [i['code'] for i in penyakit]
fod = group_concat(code_penyakit, ',')

urutan = 1
densitas_baru = []

while evidence:
    densitas1 = [evidence.pop(0)]

    densitas1.append([fod, 1 - densitas1[0][1]])
    densitas2 = []
    if not densitas_baru:
        densitas2.append(evidence.pop(0))
    else:
        for k, r in densitas_baru.items():
            if k != "&theta;":
                densitas2.append([k, r])

    theta = 1
    for d in densitas2:
        theta -= d[1]
    densitas2.append([fod, theta])
    m = len(densitas2)
    densitas_baru = {}
    for y in range(m):
        for x in range(2):
            if not (y == m - 1 and x == 1):
                v = densitas1[x][0].split(',')
                w = densitas2[y][0].split(',')
                v.sort()
                w.sort()
                vw = set(v) & set(w)
                if not vw:
                    k = "&theta;"
                else:
                    k = ','.join(vw)
                if k not in densitas_baru:
                    densitas_baru[k] = densitas1[x][1] * densitas2[y][1]
                else:
                    densitas_baru[k] += densitas1[x][1] * densitas2[y][1]

    for k, d in densitas_baru.items():
        if k != "&theta;":
            densitas_baru[k] = d / (1 - densitas_baru.get("&theta;", 0))

    # print(densitas2)
    print("Proses " + str(urutan) + " ")
    urutan += 1
    
    print(densitas_baru)
    print("========================================")


#--- perangkingan
# densitas_baru.pop("&theta;", None)
# densitas_baru = dict(sorted(densitas_baru.items(), key=lambda item: item[1], reverse=True))



