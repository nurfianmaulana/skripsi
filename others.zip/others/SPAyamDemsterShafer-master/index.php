<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
<center>
	<h1>Sistem Pakar Penyakit Ayam</h1>
	<h2>Menggunakan Motode Dempster Shafer</h2>
	<hr style="width:50%">
	
	<a href="proses.php"> <button> Diagnosa </button> </a>
</center>
</body>

</html>