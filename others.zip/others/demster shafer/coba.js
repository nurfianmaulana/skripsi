const gejala = [
    { id: 1, nama: 'Bulu Rontok' }, 
    { id: 2, nama: 'Kulit Bersisik Kemerahan Dan Bulu Kusam' }, 
    { id: 3, nama: 'Kulit Kasar' }, 
    { id: 4, nama: 'Terdapat Bintik Botak atau Lingkaran' }, 
    { id: 5, nama: 'Terdapat Kerak' }, 
    { id: 6, nama: 'Telinga Berkerak' }, 
    { id: 7, nama: 'Gatal Berlebih' }, 
    { id: 8, nama: 'Radang / Penebalan Jaringan Kuku' }, 
    { id: 9, nama: 'Kulit Bersisik' }, 
    { id: 10, nama: 'Kulit Kemerahan' }, 
    { id: 11, nama: 'Gangguan Pencernaan' }, 
    { id: 12, nama: 'Mata Berair' }, 
    { id: 13, nama: 'Lemah dan Lesu' }, 
    { id: 14, nama: 'Muncul Kutu' }, 
    { id: 15, nama: 'Peradangan Akibat Gigitan' }, 
    { id: 16, nama: 'Benjolan di kulit' }, 
    { id: 17, nama: 'Luka Pada Bibir' }, 
    { id: 18, nama: 'Demam' }, 
    { id: 19, nama: 'Bengkak Pada Bagian Yang Sakit' }, 
    { id: 20, nama: 'Nanah atau Darah Pada Kulit' }, 
    { id: 21, nama: 'Kulit Kemerahan, Bengkak  atau Meradang' },
    { id: 22, nama: 'Terdapat Kerak Putih atau Ketombe' }, 
    { id: 23, nama: 'Bulu kusam' }, 
    { id: 24, nama: 'Luka Pada Kulit' }, 
    { id: 25, nama: 'Ada Belatung Pada Luka' }, 
    { id: 26, nama: 'Bau Tidak Sedap' }, 
    { id: 27, nama: 'Bintik Hitam Pada Dagu' }, 
    { id: 28, nama: 'Pastula atau Jerawat' },
    { id: 29, nama: 'Luka Basah' },
    { id: 30, nama: 'Luka Berisi Nanah Pada Wajah' }, 
    { id: 31, nama: 'Pembengkakan Pada Bantalan Kaki' }, 
    { id: 32, nama: 'Kulit Seperti Terbakar' }
];
const penyakit = [
    { id: 1, nama: 'Ring Worm' }, 
    { id: 2, nama: 'Scabies' }, 
    { id: 3, nama: 'Alergic Dermatitis' }, 
    { id: 4, nama: 'Kutu Lice' }, 
    { id: 5, nama: 'Eosinophilic Granuloma' }, 
    { id: 6, nama: 'Abses' }, 
    { id: 7, nama: 'Kulit Kering atau Ketombe' }, 
    { id: 8, nama: 'Miasis' }, 
    { id: 9, nama: 'Feline Acne' }, 
    { id: 10, nama: 'Dermotofitosis' }, 
    { id: 11, nama: 'Pemphigus Foliaceus' }
];

const basis_pengetahuan = [
    {"id":1,"bobot":0.6,"id_gejala":1,"id_penyakit":1},
    {"id":2,"bobot":0.6,"id_gejala":2,"id_penyakit":1},
    {"id":3,"bobot":0.3,"id_gejala":3,"id_penyakit":1},
    {"id":4,"bobot":0.6,"id_gejala":4,"id_penyakit":1},
    {"id":5,"bobot":0.2,"id_gejala":5,"id_penyakit":1},
    {"id":6,"bobot":0.4,"id_gejala":1,"id_penyakit":2},
    {"id":7,"bobot":0.7,"id_gejala":6,"id_penyakit":2},
    {"id":8,"bobot":0.5,"id_gejala":7,"id_penyakit":2},
    {"id":9,"bobot":0.6,"id_gejala":8,"id_penyakit":2},
    {"id":10,"bobot":0.6,"id_gejala":9,"id_penyakit":2},
    {"id":11,"bobot":0.7,"id_gejala":10,"id_penyakit":3},
    {"id":12,"bobot":0.3,"id_gejala":11,"id_penyakit":3},
    {"id":13,"bobot":0.4,"id_gejala":12,"id_penyakit":3},
    {"id":14,"bobot":0.5,"id_gejala":13,"id_penyakit":4},
    {"id":15,"bobot":0.8,"id_gejala":14,"id_penyakit":4},
    {"id":16,"bobot":0.4,"id_gejala":15,"id_penyakit":4},
    {"id":17,"bobot":0.6,"id_gejala":16,"id_penyakit":5},
    {"id":18,"bobot":0.7,"id_gejala":17,"id_penyakit":5},
    {"id":19,"bobot":0.2,"id_gejala":1,"id_penyakit":6},
    {"id":20,"bobot":0.7,"id_gejala":18,"id_penyakit":6},
    {"id":21,"bobot":0.8,"id_gejala":19,"id_penyakit":6},
    {"id":22,"bobot":0.8,"id_gejala":20,"id_penyakit":6},
    {"id":23,"bobot":0.8,"id_gejala":21,"id_penyakit":6},
    {"id":24,"bobot":0.5,"id_gejala":13,"id_penyakit":6},
    {"id":25,"bobot":0.5,"id_gejala":1,"id_penyakit":7},
    {"id":26,"bobot":0.8,"id_gejala":22,"id_penyakit":7},
    {"id":27,"bobot":0.6,"id_gejala":23,"id_penyakit":7},
    {"id":28,"bobot":0.6,"id_gejala":7,"id_penyakit":7},
    {"id":29,"bobot":0.7,"id_gejala":24,"id_penyakit":8},
    {"id":30,"bobot":0.8,"id_gejala":25,"id_penyakit":8},
    {"id":31,"bobot":0.8,"id_gejala":26,"id_penyakit":8},
    {"id":32,"bobot":0.5,"id_gejala":27,"id_penyakit":9},
    {"id":33,"bobot":0.5,"id_gejala":28,"id_penyakit":9},
    {"id":34,"bobot":0.7,"id_gejala":10,"id_penyakit":9},
    {"id":35,"bobot":0.7,"id_gejala":1,"id_penyakit":10},
    {"id":36,"bobot":0.6,"id_gejala":10,"id_penyakit":10},
    {"id":37,"bobot":0.6,"id_gejala":7,"id_penyakit":10},
    {"id":38,"bobot":0.7,"id_gejala":5,"id_penyakit":10},
    {"id":39,"bobot":0.4,"id_gejala":29,"id_penyakit":10},
    {"id":40,"bobot":0.5,"id_gejala":30,"id_penyakit":11},
    {"id":41,"bobot":0.5,"id_gejala":31,"id_penyakit":11},
    {"id":42,"bobot":0.4,"id_gejala":6,"id_penyakit":11},
    {"id":43,"bobot":0.7,"id_gejala":32,"id_penyakit":11}
];

for (let g = 0; g < gejala.length; g++) {
    gejala[g]['code'] = `G${gejala[g]["id"]}`;
}

for (let p = 0; p < penyakit.length; p++) {
    penyakit[p]['code'] = `P${penyakit[p]["id"]}`;
}

const inputData = [18,19,20]

function joinAndGroupConcat(basisPengetahuan, penyakit, gejala) {
    // Filter basisPengetahuan by gejala
    const filteredRules = basisPengetahuan.filter(rule => gejala.includes(rule.id_gejala));

    // Perform the join operation
    const joinedData = [];
    filteredRules.forEach(rule => {
        const problem = penyakit.find(problem => problem.id === rule.id_penyakit) || null;
        joinedData.push({
            id_gejala: rule.id_gejala,
            code: problem ? problem.code : null,
            bobot: rule.bobot
        });
    });

    // Group by id_gejala and concatenate codes
    const groupedData = {};
    joinedData.forEach(item => {
        if (!groupedData[item.id_gejala]) {
            groupedData[item.id_gejala] = { codes: [], bobot: item.bobot };
        }
        groupedData[item.id_gejala].codes.push(item.code);
    });

    // Format the result
    const result = Object.keys(groupedData).map(key => ({
        id_gejala: key,
        id_penyakit: groupedData[key].codes.join(','),
        bobot: groupedData[key].bobot
    }));

    return result;
}
function groupConcat(arr, separator) {
    return arr.length === 0 ? '' : arr.join(separator);
}

const result = joinAndGroupConcat(basis_pengetahuan,penyakit,inputData);
const evidence = []

for (let i = 0; i < result.length; i++) {
    let row = result[i];
    evidence.push([row.id_penyakit, row.bobot]);
}

const codePenyakit = penyakit.map(i => i.code);
const fod = codePenyakit.join(',');

let urutan = 1;
let densitas_baru = []

while (evidence.length > 0) {
    console.log(urutan);
    let densitas1 = [evidence.shift()];

    densitas1.push([fod, 1 - densitas1[0][1]]);
    let densitas2 = [];
    if (Object.keys(densitas_baru).length === 0) {
        densitas2.push(evidence.shift());
    } else {
        for (let [k, r] of Object.entries(densitas_baru)) {
            if (k !== "&theta;") {
                densitas2.push([k, r]);
            }
        }
    }

    let theta = 1;
    for (let d of densitas2) {
        theta -= d[1];
    }
    densitas2.push([fod, theta]);
    let m = densitas2.length;
    densitas_baru = {};
    for (let y = 0; y < m; y++) {
        for (let x = 0; x < 2; x++) {
            if (!(y === m - 1 && x === 1)) {
                let v = densitas1[x][0].split(',');
                let w = densitas2[y][0].split(',');
                v.sort();
                w.sort();
                let vw = new Set(v.filter(value => w.includes(value)));
                let k = vw.size === 0 ? "&theta;" : Array.from(vw).join(',');
                if (!(k in densitas_baru)) {
                    densitas_baru[k] = densitas1[x][1] * densitas2[y][1];
                } else {
                    densitas_baru[k] += densitas1[x][1] * densitas2[y][1];
                }
            }
        }
    }

    for (let [k, d] of Object.entries(densitas_baru)) {
        if (k !== "&theta;") {
            densitas_baru[k] = d / (1 - (densitas_baru["&theta;"] || 0));
        }
    }

    // console.log(densitas2);
    console.log("Proses " + urutan + " ");
    urutan += 1;

    console.log(densitas_baru);
    console.log("========================================");
}




