# penyakit = [
#     {'id': 1, 'code': 'P1', 'name': 'Typus Ayam'},
#     {'id': 2, 'code': 'P2', 'name': 'TBC'},
#     {'id': 3, 'code': 'P3', 'name': 'Kolera'},
#     {'id': 4, 'code': 'P4', 'name': 'CRD'},
#     {'id': 5, 'code': 'P5', 'name': 'Pilek'},
#     {'id': 6, 'code': 'P6', 'name': 'Berak Lumpur'},
#     {'id': 7, 'code': 'P7', 'name': 'Berak Darah'},
#     {'id': 8, 'code': 'P8', 'name': 'Hostomatosis'},
#     {'id': 9, 'code': 'P9', 'name': 'Radang Paru - Paru'},
#     {'id': 10, 'code': 'P10', 'name': 'Influenza Ayam'},
#     {'id': 11, 'code': 'P11', 'name': 'Sesak Nafas'},
#     {'id': 12, 'code': 'P12', 'name': 'Gumoro'},
# ]
# gejala = [
#     {'id': 1, 'code': 'G1', 'name': 'ayam mengeluarkan kotor'},
#     {'id': 2, 'code': 'G2', 'name': 'jengger ayam terlihat pucat'},
#     {'id': 3, 'code': 'G3', 'name': 'nafsu makan ayam menurun'},
#     {'id': 4, 'code': 'G4', 'name': 'tingkah ayam terlihat lesu'},
#     {'id': 5, 'code': 'G5', 'name': 'ayam mudah kehausan'},
#     {'id': 6, 'code': 'G6', 'name': 'ayam mendadak mati'},
#     {'id': 7, 'code': 'G7', 'name': 'umur ayam kurang dari 1'},
#     {'id': 8, 'code': 'G8', 'name': 'dada pada ayam terlihat tipis'},
#     {'id': 9, 'code': 'G9', 'name': 'persendian pada ayam bengkak'},
#     {'id': 10, 'code': 'G10', 'name': 'ayam sulit bernafas'},
#     {'id': 11, 'code': 'G11', 'name': 'ayam batuk'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
#     {'id': 12, 'code': 'G12', 'name': 'umur ayam lebih dari 1'},
# ]
# basis_pengetahuan = [
#     {'id_penyakit': 1, 'id_gejala': 1, 'bobot': 0.7},
#     {'id_penyakit': 3, 'id_gejala': 1, 'bobot': 0.7},
#     {'id_penyakit': 1, 'id_gejala': 2, 'bobot': 0.6},
#     {'id_penyakit': 6, 'id_gejala': 2, 'bobot': 0.6},
#     {'id_penyakit': 1, 'id_gejala': 3, 'bobot': 0.8},
#     {'id_penyakit': 7, 'id_gejala': 3, 'bobot': 0.8},
#     {'id_penyakit': 9, 'id_gejala': 3, 'bobot': 0.8},
#     {'id_penyakit': 11, 'id_gejala': 3, 'bobot': 0.8},
#     {'id_penyakit': 12, 'id_gejala': 3, 'bobot': 0.8},
#     {'id_penyakit': 2, 'id_gejala': 4, 'bobot': 0.5},
#     {'id_penyakit': 9, 'id_gejala': 4, 'bobot': 0.5},
#     {'id_penyakit': 11, 'id_gejala': 4, 'bobot': 0.5},
#     {'id_penyakit': 1, 'id_gejala': 5, 'bobot': 0.6},
#     {'id_penyakit': 9, 'id_gejala': 5, 'bobot': 0.6},
#     {'id_penyakit': 1, 'id_gejala': 6, 'bobot': 0.9},
#     {'id_penyakit': 2, 'id_gejala': 7, 'bobot': 0.7},
#     {'id_penyakit': 2, 'id_gejala': 8, 'bobot': 0.6},
#     {'id_penyakit': 2, 'id_gejala': 9, 'bobot': 0.7},
#     {'id_penyakit': 9, 'id_gejala': 10, 'bobot': 0.8},
#     {'id_penyakit': 10, 'id_gejala': 10, 'bobot': 0.8},
#     {'id_penyakit': 11, 'id_gejala': 10, 'bobot': 0.8},
#     {'id_penyakit': 4, 'id_gejala': 11, 'bobot': 0.6},
#     {'id_penyakit': 5, 'id_gejala': 11, 'bobot': 0.6},
#     {'id_penyakit': 10, 'id_gejala': 11, 'bobot': 0.6},
#     {'id_penyakit': 4, 'id_gejala': 12, 'bobot': 0.5},
#     {'id_penyakit': 6, 'id_gejala': 13, 'bobot': 0.7},
# ]
# penyakit = [
#     {'id':1, 'code': 'P1', 'name':'Ring Worm'},
#     {'id':2, 'code': 'P2', 'name':'Scabies'},
#     {'id':3, 'code': 'P3', 'name':'Alergic Dematitis'},
#     {'id':4, 'code': 'P4', 'name':'Kutu Lice'},
#     {'id':5, 'code': 'P5', 'name':'Eosinophilic granuloma'},
#     {'id':6, 'code': 'P6', 'name':'Abses'},
#     {'id':7, 'code': 'P7', 'name': 'Kulit Kering / Ketombe'},
#     {'id':8, 'code': 'P8', 'name': 'Miasis'},
# ]
# gejala = [
#     {'id':1, 'code': 'G1', 'name': 'Bulu Rontok'},
#     {'id':2, 'code': 'G2', 'name': 'Kulit Kemerahan'},
#     {'id':3, 'code': 'G3', 'name': 'Kulit Kasar'},
#     {'id':5, 'code': 'G4', 'name': 'Bintik Bundar Dikulit'},
#     {'id':6, 'code': 'G5', 'name': 'Terdapat Kerak'},
#     {'id':7, 'code': 'G6', 'name': 'Pinggir Telinga Berkerak'},
#     {'id':9, 'code': 'G7', 'name': 'Menggaruk Telinga Berlebih'},
#     {'id':10, 'code': 'G8', 'name': 'Radang'},
#     {'id':11, 'code': 'G9', 'name': 'Kulit Bersisik'},
#     {'id':12, 'code': 'G10', 'name': 'Gangguan Pencernaan'},
#     {'id':13, 'code': 'G11', 'name': 'Mata Berair'},
#     {'id':14, 'code': 'G12', 'name': 'Lemah/Lesu'},
#     {'id':15, 'code': 'G13', 'name': 'Muncul Kutu'},
#     {'id':16, 'code': 'G14', 'name': 'Radang Akibat Gigitan'},
#     {'id':17, 'code': 'G15', 'name': 'Benjolan Dikulit'},
#     {'id':18, 'code': 'G16', 'name': 'Luka Pada Bibir'},
#     {'id':19, 'code': 'G17', 'name': 'Demam'},
#     {'id':20, 'code': 'G18', 'name': 'Bengkak Pada Bagian Sakit'},
#     {'id':21, 'code': 'G19', 'name': 'Nanah Pada Bagian Sakit'},
#     {'id':22, 'code': 'G20', 'name': 'Ketombe/Kerak Putih'},
#     {'id':23, 'code': 'G21', 'name': 'Bulu Kusam'},
#     {'id':24, 'code': 'G22', 'name': 'Menggaruk Berlebih'},
#     {'id':25, 'code': 'G23', 'name': 'Luka Pada Bagian Kulit'},
#     {'id':26, 'code': 'G24', 'name': 'Ada Belatung Pada Luka'}
# ]
# basis_pengetahuan = [
#     {'bobot': 0.6, 'id_gejala':1, 'id_penyakit': 1},
#     {'bobot': 0.6, 'id_gejala':1, 'id_penyakit': 2},
#     {'bobot': 0.6, 'id_gejala':1, 'id_penyakit': 6},
#     {'bobot': 0.6, 'id_gejala':1, 'id_penyakit': 7},
#     {'bobot': 0.6, 'id_gejala':2, 'id_penyakit':1},
#     {'bobot': 0.6, 'id_gejala':2, 'id_penyakit':3},
#     {'bobot': 0.4, 'id_gejala':3, 'id_penyakit':1},
#     {'bobot': 0.8, 'id_gejala':5, 'id_penyakit':1},
#     {'bobot': 0.6, 'id_gejala':6, 'id_penyakit':1},
#     {'bobot': 0.8, 'id_gejala':7, 'id_penyakit':2},
#     {'bobot': 0.8, 'id_gejala':9, 'id_penyakit':2},
#     {'bobot': 0.8, 'id_gejala':10, 'id_penyakit':2},
#     {'bobot': 0.6, 'id_gejala':11, 'id_penyakit':2},
#     {'bobot': 0.6, 'id_gejala':12, 'id_penyakit':3},
#     {'bobot': 0.4, 'id_gejala':13,'id_penyakit': 3},
#     {'bobot': 0.6, 'id_gejala':14,'id_penyakit': 4},
#     {'bobot': 0.6, 'id_gejala':14, 'id_penyakit':6},
#     {'bobot': 0.8, 'id_gejala':15, 'id_penyakit':4},
#     {'bobot': 0.6, 'id_gejala':16, 'id_penyakit':4},
#     {'bobot': 0.6, 'id_gejala':17, 'id_penyakit':5},
#     {'bobot': 0.6, 'id_gejala':18, 'id_penyakit':5},
#     {'bobot': 0.8, 'id_gejala':19,'id_penyakit': 6},
#     {'bobot': 1,   'id_gejala':20, 'id_penyakit':6},
#     {'bobot': 1,   'id_gejala':21, 'id_penyakit':6},
#     {'bobot': 1,   'id_gejala':22, 'id_penyakit':7},
#     {'bobot': 0.8, 'id_gejala':23, 'id_penyakit':7},
#     {'bobot': 0.8, 'id_gejala':24, 'id_penyakit':7},
#     {'bobot': 1,   'id_gejala':25, 'id_penyakit':8},
#     {'bobot': 1,    'id_gejala':26, 'id_penyakit':8}
# ]


gejala = [
    {'id': 1, 'nama': 'Bulu Rontok'}, 
    {'id': 2, 'nama': 'Kulit Bersisik Kemerahan Dan Bulu Kusam'}, 
    {'id': 3, 'nama': 'Kulit Kasar'}, 
    {'id': 4, 'nama': 'Terdapat Bintik Botak atau Lingkaran'}, 
    {'id': 5, 'nama': 'Terdapat Kerak'}, 
    {'id': 6, 'nama': 'Telinga Berkerak'}, 
    {'id': 7, 'nama': 'Gatal Berlebih'}, 
    {'id': 8, 'nama': 'Radang / Penebalan Jaringan Kuku'}, 
    {'id': 9, 'nama': 'Kulit Bersisik'}, 
    {'id': 10, 'nama': 'Kulit Kemerahan'}, 
    {'id': 11, 'nama': 'Gangguan Pencernaan'}, 
    {'id': 12, 'nama': 'Mata Berair'}, 
    {'id': 13, 'nama': 'Lemah dan Lesu'}, 
    {'id': 14, 'nama': 'Muncul Kutu'}, 
    {'id': 15, 'nama': 'Peradangan Akibat Gigitan'}, 
    {'id': 16, 'nama': 'Benjolan di kulit'}, 
    {'id': 17, 'nama': 'Luka Pada Bibir'}, 
    {'id': 18, 'nama': 'Demam'}, 
    {'id': 19, 'nama': 'Bengkak Pada Bagian Yang Sakit'}, 
    {'id': 20, 'nama': 'Nanah atau Darah Pada Kulit'}, 
    {'id': 21, 'nama': 'Kulit Kemerahan, Bengkak  atau Meradang'},
    {'id': 22, 'nama': 'Terdapat Kerak Putih atau Ketombe'}, 
    {'id': 23, 'nama': 'Bulu kusam'}, 
    {'id': 24, 'nama': 'Luka Pada Kulit'}, 
    {'id': 25, 'nama': 'Ada Belatung Pada Luka'}, 
    {'id': 26, 'nama': 'Bau Tidak Sedap'}, 
    {'id': 27, 'nama': 'Bintik Hitam Pada Dagu'}, 
    {'id': 28, 'nama': 'Pastula atau Jerawat'},
    {'id': 29, 'nama': 'Luka Basah'},
    {'id': 30, 'nama': 'Luka Berisi Nanah Pada Wajah'}, 
    {'id': 31, 'nama': 'Pembengkakan Pada Bantalan Kaki'}, 
    {'id': 32, 'nama': 'Kulit Seperti Terbakar'}
]
penyakit = [
    {'id': 1, 'nama': 'Ring Worm'}, 
    {'id': 2, 'nama': 'Scabies'}, 
    {'id': 3, 'nama': 'Alergic Dermatitis'}, 
    {'id': 4, 'nama': 'Kutu Lice'}, 
    {'id': 5, 'nama': 'Eosinophilic Granuloma'}, 
    {'id': 6, 'nama': 'Abses'}, 
    {'id': 7, 'nama': 'Kulit Kering atau Ketombe'}, 
    {'id': 8, 'nama': 'Miasis'}, 
    {'id': 9, 'nama': 'Feline Acne'}, 
    {'id': 10, 'nama': 'Dermotofitosis'}, 
    {'id': 11, 'nama': 'Pemphigus Foliaceus'}]
basis_pengetahuan = [
    {"id":1,"bobot":0.6,"id_gejala":1,"id_penyakit":1},
    {"id":2,"bobot":0.6,"id_gejala":2,"id_penyakit":1},
    {"id":3,"bobot":0.3,"id_gejala":3,"id_penyakit":1},
    {"id":4,"bobot":0.6,"id_gejala":4,"id_penyakit":1},
    {"id":5,"bobot":0.2,"id_gejala":5,"id_penyakit":1},
    {"id":6,"bobot":0.4,"id_gejala":1,"id_penyakit":2},
    {"id":7,"bobot":0.7,"id_gejala":6,"id_penyakit":2},
    {"id":8,"bobot":0.5,"id_gejala":7,"id_penyakit":2},
    {"id":9,"bobot":0.6,"id_gejala":8,"id_penyakit":2},
    {"id":10,"bobot":0.6,"id_gejala":9,"id_penyakit":2},
    {"id":11,"bobot":0.7,"id_gejala":10,"id_penyakit":3},
    {"id":12,"bobot":0.3,"id_gejala":11,"id_penyakit":3},
    {"id":13,"bobot":0.4,"id_gejala":12,"id_penyakit":3},
    {"id":14,"bobot":0.5,"id_gejala":13,"id_penyakit":4},
    {"id":15,"bobot":0.8,"id_gejala":14,"id_penyakit":4},
    {"id":16,"bobot":0.4,"id_gejala":15,"id_penyakit":4},
    {"id":17,"bobot":0.6,"id_gejala":16,"id_penyakit":5},
    {"id":18,"bobot":0.7,"id_gejala":17,"id_penyakit":5},
    {"id":19,"bobot":0.2,"id_gejala":1,"id_penyakit":6},
    {"id":20,"bobot":0.7,"id_gejala":18,"id_penyakit":6},
    {"id":21,"bobot":0.8,"id_gejala":19,"id_penyakit":6},
    {"id":22,"bobot":0.8,"id_gejala":20,"id_penyakit":6},
    {"id":23,"bobot":0.8,"id_gejala":21,"id_penyakit":6},
    {"id":24,"bobot":0.5,"id_gejala":13,"id_penyakit":6},
    {"id":25,"bobot":0.5,"id_gejala":1,"id_penyakit":7},
    {"id":26,"bobot":0.8,"id_gejala":22,"id_penyakit":7},
    {"id":27,"bobot":0.6,"id_gejala":23,"id_penyakit":7},
    {"id":28,"bobot":0.6,"id_gejala":7,"id_penyakit":7},
    {"id":29,"bobot":0.7,"id_gejala":24,"id_penyakit":8},
    {"id":30,"bobot":0.8,"id_gejala":25,"id_penyakit":8},
    {"id":31,"bobot":0.8,"id_gejala":26,"id_penyakit":8},
    {"id":32,"bobot":0.5,"id_gejala":27,"id_penyakit":9},
    {"id":33,"bobot":0.5,"id_gejala":28,"id_penyakit":9},
    {"id":34,"bobot":0.7,"id_gejala":10,"id_penyakit":9},
    {"id":35,"bobot":0.7,"id_gejala":1,"id_penyakit":10},
    {"id":36,"bobot":0.6,"id_gejala":10,"id_penyakit":10},
    {"id":37,"bobot":0.6,"id_gejala":7,"id_penyakit":10},
    {"id":38,"bobot":0.7,"id_gejala":5,"id_penyakit":10},
    {"id":39,"bobot":0.4,"id_gejala":29,"id_penyakit":10},
    {"id":40,"bobot":0.5,"id_gejala":30,"id_penyakit":11},
    {"id":41,"bobot":0.5,"id_gejala":31,"id_penyakit":11},
    {"id":42,"bobot":0.4,"id_gejala":6,"id_penyakit":11},
    {"id":43,"bobot":0.7,"id_gejala":32,"id_penyakit":11}
]

for g in range(len(gejala)):
    gejala[g]['code'] = f'G{gejala[g]["id"]}'

for p in range(len(penyakit)):
    penyakit[p]['code'] = f'P{penyakit[p]["id"]}'

print(gejala)
# input_data = [27,28,10]
# input_data = [10,27,28]
# input_data = [30,31,32]
# input_data= [1,7,29,]
# input_data = [24,25,26]
input_data = [18,19,20]

def join_and_group_concat(basis_pengetahuan, penyakit, gejala):
    # Filter basis_pengetahuan by gejala
    filtered_rules = [rule for rule in basis_pengetahuan if rule['id_gejala'] in gejala]

    # Perform the join operation
    joined_data = []
    for rule in filtered_rules:
        problem = next((problem for problem in penyakit if problem['id'] == rule['id_penyakit']), None)
        joined_data.append({
            'id_gejala': rule['id_gejala'],
            'code': problem['code'] if problem else None,
            'bobot': rule['bobot']
        })

    # Group by id_gejala and concatenate codes
    grouped_data = {}
    for item in joined_data:
        if item['id_gejala'] not in grouped_data:
            grouped_data[item['id_gejala']] = {'codes': [], 'bobot': item['bobot']}
        grouped_data[item['id_gejala']]['codes'].append(item['code'])

    # Format the result
    result = [{
        'id_gejala': key,
        'id_penyakit': ','.join(grouped_data[key]['codes']),
        'bobot': grouped_data[key]['bobot']
    } for key in grouped_data]

    return result

def group_concat(arr, separator):
    return ''.join(arr) if not arr else separator.join(arr)

result = join_and_group_concat(basis_pengetahuan, penyakit, input_data)
evidence = []

for i in range(len(result)):
    row = result[i]
    evidence.append([row['id_penyakit'], row['bobot']])

code_penyakit = [i['code'] for i in penyakit]
fod = group_concat(code_penyakit, ',')

urutan = 1
densitas_baru = []

while evidence:
    print(urutan)
    densitas1 = [evidence.pop(0)]

    densitas1.append([fod, 1 - densitas1[0][1]])
    densitas2 = []
    if not densitas_baru:
        densitas2.append(evidence.pop(0))
    else:
        for k, r in densitas_baru.items():
            if k != "&theta;":
                densitas2.append([k, r])

    theta = 1
    for d in densitas2:
        theta -= d[1]
    densitas2.append([fod, theta])
    m = len(densitas2)
    densitas_baru = {}
    for y in range(m):
        for x in range(2):
            if not (y == m - 1 and x == 1):
                v = densitas1[x][0].split(',')
                w = densitas2[y][0].split(',')
                v.sort()
                w.sort()
                vw = set(v) & set(w)
                if not vw:
                    k = "&theta;"
                else:
                    k = ','.join(vw)
                if k not in densitas_baru:
                    densitas_baru[k] = densitas1[x][1] * densitas2[y][1]
                else:
                    densitas_baru[k] += densitas1[x][1] * densitas2[y][1]

    for k, d in densitas_baru.items():
        if k != "&theta;":
            densitas_baru[k] = d / (1 - densitas_baru.get("&theta;", 0))

    # print(densitas2)
    print("Proses " + str(urutan) + " ")
    urutan += 1
    
    print(densitas_baru)
    print("========================================")


#--- perangkingan
densitas_baru.pop("&theta;", None)
densitas_baru = dict(sorted(densitas_baru.items(), key=lambda item: item[1], reverse=True))



