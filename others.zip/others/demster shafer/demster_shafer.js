const penyakit = [
    {id:1, code:'P1', name:'Typus Ayam'},
    {id:2, code:'P2', name:'TBC'},
    {id:3, code:'P3', name:'Kolera'},
    {id:4, code:'P4', name:'CRD'},
    {id:5, code:'P5', name:'Pilek'},
    {id:6, code:'P6', name:'Berak Lumpur'},
    {id:7, code:'P7', name:'Berak Darah'},
    {id:8, code:'P8', name:'Hostomatosis'},
    {id:9, code:'P9', name:'Radang Paru - Paru'},
    {id:10, code:'P10', name:'Influenza Ayam'},
    {id:11, code:'P11', name:'Sesak Nafas'},
    {id:12, code:'P12', name:'Gumoro'},
]
const gejala = [
    {id:1, code:'G1', name:'ayam mengeluarkan kotor'},
    {id:2, code:'G2', name:'jengger ayam terlihat pucat'},
    {id:3, code:'G3', name:'nafsu makan ayam menurun'},
    {id:4, code:'G4', name:'tingkah ayam terlihat lesu'},
    {id:5, code:'G5', name:'ayam mudah kehausan'},
    {id:6, code:'G6', name:'ayam mendadak mati'},
    {id:7, code:'G7', name:'umur ayam kurang dari 1'},
    {id:8, code:'G8', name:'dada pada ayam terlihat tipis'},
    {id:9, code:'G9', name:'persendian pada ayam bengkak'},
    {id:10, code:'G10', name:'ayam sulit bernafas'},
    {id:11, code:'G11', name:'ayam batuk'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
    {id:12, code:'G12', name:'umur ayam lebih dari 1'},
]
const basisPengetahuan = [
    {id_penyakit:1,id_gejala:1,bobot:0.7},
    {id_penyakit:3,id_gejala:1,bobot:0.7},
    {id_penyakit:1,id_gejala:2,bobot:0.6},
    {id_penyakit:6,id_gejala:2,bobot:0.6},
    {id_penyakit:1,id_gejala:3,bobot:0.8},
    {id_penyakit:7,id_gejala:3,bobot:0.8},
    {id_penyakit:9,id_gejala:3,bobot:0.8},
    {id_penyakit:11,id_gejala:3,bobot:0.8},
    {id_penyakit:12,id_gejala:3,bobot:0.8},
    {id_penyakit:2,id_gejala:4,bobot:0.5},
    {id_penyakit:9,id_gejala:4,bobot:0.5},
    {id_penyakit:11,id_gejala:4,bobot:0.5},
    {id_penyakit:1,id_gejala:5,bobot:0.6},
    {id_penyakit:9,id_gejala:5,bobot:0.6},
    {id_penyakit:1,id_gejala:6,bobot:0.9},
    {id_penyakit:2,id_gejala:7,bobot:0.7},
    {id_penyakit:2,id_gejala:8,bobot:0.6},
    {id_penyakit:2,id_gejala:9,bobot:0.7},
    {id_penyakit:9,id_gejala:10,bobot:0.8},
    {id_penyakit:10,id_gejala:10,bobot:0.8},
    {id_penyakit:11,id_gejala:10,bobot:0.8},
    {id_penyakit:4,id_gejala:11,bobot:0.6},
    {id_penyakit:5,id_gejala:11,bobot:0.6},
    {id_penyakit:10,id_gejala:11,bobot:0.6},
    {id_penyakit:4,id_gejala:12,bobot:0.5},
    {id_penyakit:6,id_gejala:13,bobot:0.7},
]
const inputData = [1,2,3]

function joinAndGroupConcat(basisPengetahuan, penyakit, gejala) {
    // Filter basisPengetahuan by gejala
    const filteredRules = basisPengetahuan.filter(rule => gejala.includes(rule.id_gejala));

    // Perform the join operation
    const joinedData = filteredRules.map(rule => {
        const problem = penyakit.find(problem => problem.id === rule.id_penyakit);
        return {
            id_gejala: rule.id_gejala,
            code: problem ? problem.code : null,
            bobot: rule.bobot
        };
    });

    // Group by id_gejala and concatenate codes
    const groupedData = joinedData.reduce((acc, item) => {
        if (!acc[item.id_gejala]) {
            acc[item.id_gejala] = { codes: [], bobot: item.bobot };
        }
        acc[item.id_gejala].codes.push(item.code);
        return acc;
    }, {});

    // Format the result
    const result = Object.keys(groupedData).map(key => ({
        id_gejala: key,
        id_penyakit: groupedData[key].codes.join(','),
        bobot: groupedData[key].bobot
    }));

    return result;
}
function groupConcat(arr, separator) {
    return arr.reduce((acc, current) => {
        if (acc === '') {
            return current;
        } else {
            return acc + separator + current;
        }
    }, '');
}

const result = joinAndGroupConcat(basisPengetahuan,penyakit,inputData);
const evidence = [];

for (let i = 0; i < result.length; i++) {
    const row = result[i];
    evidence.push([row.id_penyakit, row.bobot]);
}

const code_penyakit = penyakit.map(i => i.code);
const fod = groupConcat(code_penyakit, ',');

let urutan =1;
let densitas_baru = [];

while (evidence.length > 0) {
    let densitas1 = [evidence.shift()];

    densitas1.push([fod, 1 - densitas1[0][1]]);
    let densitas2 = [];
    if (Object.keys(densitas_baru).length === 0) {
        densitas2.push(evidence.shift());
    } else {
        for (let [k, r] of Object.entries(densitas_baru)) {
            if (k !== "&theta;") {
                densitas2.push([k, r]);
            }
        }
    }

    let theta = 1;
    for (let d of densitas2) {
        theta -= d[1];
    }
    densitas2.push([fod, theta]);
    let m = densitas2.length;
    densitas_baru = {};
    for (let y = 0; y < m; y++) {
        for (let x = 0; x < 2; x++) {
            if (!(y === m - 1 && x === 1)) {
                let v = densitas1[x][0].split(',');
                let w = densitas2[y][0].split(',');
                v.sort();
                w.sort();
                let vw = new Set(v.filter(item => w.includes(item)));
                let k = vw.size === 0 ? "&theta;" : Array.from(vw).join(',');
                if (!(k in densitas_baru)) {
                    densitas_baru[k] = densitas1[x][1] * densitas2[y][1];
                } else {
                    densitas_baru[k] += densitas1[x][1] * densitas2[y][1];
                }
            }
        }
    }

    for (let [k, d] of Object.entries(densitas_baru)) {
        if (k !== "&theta;") {
            densitas_baru[k] = d / (1 - (densitas_baru["&theta;"] || 0));
        }
    }

    // console.log(densitas2);
    console.log("Proses " + urutan + " ");
    urutan += 1;

    console.log(densitas_baru);
    console.log("========================================");
}

// while (evidence.length > 0) {
//     // let densitas1 = [];
//     densitas1[0] = evidence.shift();
//     densitas1[1] = [fod, 1 - densitas1[0][1]];
//     let densitas2 = [];
    
//     if (densitas_baru.length === 0) {
//         densitas2[0] = evidence.shift();
//     } else {
//         for (let k = 0; k < densitas_baru.length; k++) {
//             const r = densitas_baru[k];
//             if (k !== "&theta;") {
//                 densitas2.push([k, r]);
//             }
//         }
//     }
    
//     let theta = 1;
//     for (const d of densitas2) theta -= d[1];
    
//     densitas2.push([fod, theta]);
//     const m = densitas2.length;
//     densitas_baru = {};
    
//     for (let y = 0; y < m; y++) {
//         for (let x = 0; x < 2; x++) {
//             if (!(y === m - 1 && x === 1)) {
//                 let v = densitas1[x][0].split(',');
//                 let w = densitas2[y][0].split(',');
//                 v.sort();
//                 w.sort();
//                 let vw = v.filter(value => w.includes(value));
//                 let k;
//                 if (vw.length === 0) {
//                     k = "&theta;";
//                 } else {
//                     k = vw.join(',');
//                 }
//                 if (!densitas_baru.hasOwnProperty(k)) {
//                     densitas_baru[k] = densitas1[x][1] * densitas2[y][1];
//                 } else {
//                     densitas_baru[k] += densitas1[x][1] * densitas2[y][1];
//                 }
//             }
//         }
//     }
    
//     for (const [k, d] of Object.entries(densitas_baru)) {
//         if (k !== "&theta;") {
//             densitas_baru[k] = d / (1 - (densitas_baru["&theta;"] || 0));
//         }
//     }
    
//     console.log(" Proses " + urutan + " ");
//     urutan++;
//     console.log(densitas_baru);
//     console.log("=============");
// }

