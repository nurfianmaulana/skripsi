from django.db import models

class Gejala(models.Model):
    nama = models.CharField(max_length=100)

    def __str__(self):
        return self.nama

class Penyakit(models.Model):
    nama        = models.CharField(max_length=255)
    definisi    = models.TextField()
    solusi      = models.TextField()

    def __str__(self):
        return self.nama
    
class BasisPengetahuan(models.Model):
    kode_gejala = models.ForeignKey(Gejala, on_delete=models.CASCADE)
    kode_penyakit = models.ForeignKey(Penyakit, on_delete=models.CASCADE)
    bobot = models.FloatField()
