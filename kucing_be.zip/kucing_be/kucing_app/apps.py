from django.apps import AppConfig


class KucingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kucing_app'
